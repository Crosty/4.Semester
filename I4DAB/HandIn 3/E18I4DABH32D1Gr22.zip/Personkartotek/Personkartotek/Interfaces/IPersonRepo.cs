﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Personkartotek.Models;

namespace Personkartotek.Interfaces
{
    public interface IPersonRepo : IRepository<Person>
    {

    }
}
