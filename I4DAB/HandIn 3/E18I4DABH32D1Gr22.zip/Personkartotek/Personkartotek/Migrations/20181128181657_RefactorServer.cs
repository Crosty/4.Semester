﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace Personkartotek.Migrations
{
    public partial class RefactorServer : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
